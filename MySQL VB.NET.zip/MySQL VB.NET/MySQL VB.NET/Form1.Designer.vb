﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Panel1 = New Panel()
        Panel2 = New Panel()
        Label1 = New Label()
        Panel3 = New Panel()
        Panel6 = New Panel()
        TBsearch = New TextBox()
        Panel5 = New Panel()
        btnEXIT = New Button()
        btnPRINT = New Button()
        btnRESET = New Button()
        btnDELETE = New Button()
        btnUPDATE = New Button()
        btnADDNEW = New Button()
        Panel4 = New Panel()
        DataGridView1 = New DataGridView()
        TBtelephone = New TextBox()
        Label7 = New Label()
        TBpostcode = New TextBox()
        Label6 = New Label()
        TBaddress = New TextBox()
        Label5 = New Label()
        TBsurname = New TextBox()
        Label4 = New Label()
        TBfirstname = New TextBox()
        Label3 = New Label()
        TBstudentid = New TextBox()
        Label2 = New Label()
        ToolTip1 = New ToolTip(components)
        PrintDocument1 = New Printing.PrintDocument()
        PrintPreviewDialog1 = New PrintPreviewDialog()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        Panel6.SuspendLayout()
        Panel5.SuspendLayout()
        Panel4.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.CadetBlue
        Panel1.Controls.Add(Panel2)
        Panel1.Location = New Point(12, 12)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1009, 97)
        Panel1.TabIndex = 0
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = SystemColors.Control
        Panel2.Controls.Add(Label1)
        Panel2.Location = New Point(18, 14)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(971, 68)
        Panel2.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 44.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.CadetBlue
        Label1.Location = New Point(66, 3)
        Label1.Name = "Label1"
        Label1.Size = New Size(832, 67)
        Label1.TabIndex = 0
        Label1.Text = "MySQL Connection in VB.Net"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.CadetBlue
        Panel3.Controls.Add(Panel6)
        Panel3.Controls.Add(Panel5)
        Panel3.Controls.Add(Panel4)
        Panel3.Location = New Point(12, 115)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(1009, 535)
        Panel3.TabIndex = 2
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = SystemColors.Control
        Panel6.Controls.Add(TBsearch)
        Panel6.Location = New Point(703, 14)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(286, 118)
        Panel6.TabIndex = 3
        ' 
        ' TBsearch
        ' 
        TBsearch.Location = New Point(16, 19)
        TBsearch.Multiline = True
        TBsearch.Name = "TBsearch"
        TBsearch.Size = New Size(253, 76)
        TBsearch.TabIndex = 3
        ToolTip1.SetToolTip(TBsearch, "Search")
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = SystemColors.Control
        Panel5.Controls.Add(btnEXIT)
        Panel5.Controls.Add(btnPRINT)
        Panel5.Controls.Add(btnRESET)
        Panel5.Controls.Add(btnDELETE)
        Panel5.Controls.Add(btnUPDATE)
        Panel5.Controls.Add(btnADDNEW)
        Panel5.Location = New Point(703, 151)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(286, 369)
        Panel5.TabIndex = 2
        ' 
        ' btnEXIT
        ' 
        btnEXIT.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnEXIT.Location = New Point(16, 307)
        btnEXIT.Name = "btnEXIT"
        btnEXIT.Size = New Size(255, 50)
        btnEXIT.TabIndex = 5
        btnEXIT.Text = "EXIT"
        ToolTip1.SetToolTip(btnEXIT, "Exit")
        btnEXIT.UseVisualStyleBackColor = True
        ' 
        ' btnPRINT
        ' 
        btnPRINT.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnPRINT.Location = New Point(16, 251)
        btnPRINT.Name = "btnPRINT"
        btnPRINT.Size = New Size(255, 50)
        btnPRINT.TabIndex = 4
        btnPRINT.Text = "PRINT"
        ToolTip1.SetToolTip(btnPRINT, "Print")
        btnPRINT.UseVisualStyleBackColor = True
        ' 
        ' btnRESET
        ' 
        btnRESET.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnRESET.Location = New Point(16, 195)
        btnRESET.Name = "btnRESET"
        btnRESET.Size = New Size(255, 50)
        btnRESET.TabIndex = 3
        btnRESET.Text = "RESET"
        ToolTip1.SetToolTip(btnRESET, "Reset")
        btnRESET.UseVisualStyleBackColor = True
        ' 
        ' btnDELETE
        ' 
        btnDELETE.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnDELETE.Location = New Point(16, 139)
        btnDELETE.Name = "btnDELETE"
        btnDELETE.Size = New Size(255, 50)
        btnDELETE.TabIndex = 2
        btnDELETE.Text = "DELETE"
        ToolTip1.SetToolTip(btnDELETE, "Delete")
        btnDELETE.UseVisualStyleBackColor = True
        ' 
        ' btnUPDATE
        ' 
        btnUPDATE.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnUPDATE.Location = New Point(16, 83)
        btnUPDATE.Name = "btnUPDATE"
        btnUPDATE.Size = New Size(255, 50)
        btnUPDATE.TabIndex = 1
        btnUPDATE.Text = "UPDATE"
        ToolTip1.SetToolTip(btnUPDATE, "Update")
        btnUPDATE.UseVisualStyleBackColor = True
        ' 
        ' btnADDNEW
        ' 
        btnADDNEW.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnADDNEW.Location = New Point(16, 27)
        btnADDNEW.Name = "btnADDNEW"
        btnADDNEW.Size = New Size(255, 50)
        btnADDNEW.TabIndex = 0
        btnADDNEW.Text = "ADD NEW"
        ToolTip1.SetToolTip(btnADDNEW, "Add New")
        btnADDNEW.UseVisualStyleBackColor = True
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = SystemColors.Control
        Panel4.Controls.Add(DataGridView1)
        Panel4.Controls.Add(TBtelephone)
        Panel4.Controls.Add(Label7)
        Panel4.Controls.Add(TBpostcode)
        Panel4.Controls.Add(Label6)
        Panel4.Controls.Add(TBaddress)
        Panel4.Controls.Add(Label5)
        Panel4.Controls.Add(TBsurname)
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(TBfirstname)
        Panel4.Controls.Add(Label3)
        Panel4.Controls.Add(TBstudentid)
        Panel4.Controls.Add(Label2)
        Panel4.Location = New Point(18, 14)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(665, 506)
        Panel4.TabIndex = 1
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(15, 330)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(635, 159)
        DataGridView1.TabIndex = 13
        ' 
        ' TBtelephone
        ' 
        TBtelephone.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        TBtelephone.Location = New Point(199, 269)
        TBtelephone.Name = "TBtelephone"
        TBtelephone.Size = New Size(451, 44)
        TBtelephone.TabIndex = 12
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label7.Location = New Point(22, 277)
        Label7.Name = "Label7"
        Label7.Size = New Size(176, 37)
        Label7.TabIndex = 11
        Label7.Text = "Telephone"
        ' 
        ' TBpostcode
        ' 
        TBpostcode.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        TBpostcode.Location = New Point(199, 219)
        TBpostcode.Name = "TBpostcode"
        TBpostcode.Size = New Size(451, 44)
        TBpostcode.TabIndex = 10
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label6.Location = New Point(22, 227)
        Label6.Name = "Label6"
        Label6.Size = New Size(175, 37)
        Label6.TabIndex = 9
        Label6.Text = "Post Code"
        ' 
        ' TBaddress
        ' 
        TBaddress.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        TBaddress.Location = New Point(199, 169)
        TBaddress.Name = "TBaddress"
        TBaddress.Size = New Size(451, 44)
        TBaddress.TabIndex = 8
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label5.Location = New Point(22, 177)
        Label5.Name = "Label5"
        Label5.Size = New Size(142, 37)
        Label5.TabIndex = 7
        Label5.Text = "Address"
        ' 
        ' TBsurname
        ' 
        TBsurname.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        TBsurname.Location = New Point(199, 119)
        TBsurname.Name = "TBsurname"
        TBsurname.Size = New Size(451, 44)
        TBsurname.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label4.Location = New Point(22, 127)
        Label4.Name = "Label4"
        Label4.Size = New Size(154, 37)
        Label4.TabIndex = 5
        Label4.Text = "Surname"
        ' 
        ' TBfirstname
        ' 
        TBfirstname.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        TBfirstname.Location = New Point(199, 69)
        TBfirstname.Name = "TBfirstname"
        TBfirstname.Size = New Size(451, 44)
        TBfirstname.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label3.Location = New Point(22, 77)
        Label3.Name = "Label3"
        Label3.Size = New Size(169, 37)
        Label3.TabIndex = 3
        Label3.Text = "Firstname"
        ' 
        ' TBstudentid
        ' 
        TBstudentid.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        TBstudentid.Location = New Point(199, 19)
        TBstudentid.Name = "TBstudentid"
        TBstudentid.Size = New Size(451, 44)
        TBstudentid.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 24F, FontStyle.Bold)
        Label2.Location = New Point(22, 27)
        Label2.Name = "Label2"
        Label2.Size = New Size(177, 37)
        Label2.TabIndex = 1
        Label2.Text = "Student ID"
        ' 
        ' PrintDocument1
        ' 
        ' 
        ' PrintPreviewDialog1
        ' 
        PrintPreviewDialog1.AutoScrollMargin = New Size(0, 0)
        PrintPreviewDialog1.AutoScrollMinSize = New Size(0, 0)
        PrintPreviewDialog1.ClientSize = New Size(400, 300)
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.Enabled = True
        PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), Icon)
        PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        PrintPreviewDialog1.Visible = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1061, 683)
        Controls.Add(Panel3)
        Controls.Add(Panel1)
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        Panel1.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents TBsearch As TextBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TBstudentid As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TBtelephone As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TBpostcode As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TBaddress As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TBsurname As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TBfirstname As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnADDNEW As Button
    Friend WithEvents btnEXIT As Button
    Friend WithEvents btnPRINT As Button
    Friend WithEvents btnRESET As Button
    Friend WithEvents btnDELETE As Button
    Friend WithEvents btnUPDATE As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
