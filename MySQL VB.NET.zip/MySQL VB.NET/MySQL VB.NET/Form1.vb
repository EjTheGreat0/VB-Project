﻿Imports MySql.Data.MySqlClient
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.Win32
Imports Org.BouncyCastle.Crypto

Public Class Form1

    Dim sqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlRd As MySqlDataReader
    Dim sqlDt As New DataTable
    Dim sqlQuery As String
    Dim DLA As New MySqlDataAdapter

    Dim server As String = "localhost"
    Dim username As String = "root"
    Dim password As String = ""
    Dim database As String = "myconnector"

    Dim bitmap As Bitmap


    Private Sub updatetable()
        Try
            sqlConn.ConnectionString = "server=" & server & ";user id=" & username & ";password=" & password & ";database=" & database
            sqlConn.Open()
            sqlCmd.Connection = sqlConn
            sqlCmd.CommandText = "SELECT * FROM myconnector"

            sqlRd = sqlCmd.ExecuteReader
            sqlDt.Load(sqlRd)
            sqlRd.Close()
            sqlConn.Close()
            DataGridView1.DataSource = sqlDt

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            sqlConn.Dispose()
        End Try
    End Sub

    ' Add New Button Event
    Private Sub btnADDNEW_Click(sender As Object, e As EventArgs) Handles btnADDNEW.Click
        Try
            sqlConn.ConnectionString = "server=" & server & ";user id=" & username & ";password=" & password & ";database=" & database
            sqlConn.Open()
            sqlQuery = "INSERT INTO myconnector (StudentID, FirstName, Surname, Address, PostCode, Telephone)
                        VALUES (@StudentID, @FirstName, @Surname, @Address, @PostCode, @Telephone)"
            sqlCmd = New MySqlCommand(sqlQuery, sqlConn)

            With sqlCmd.Parameters
                .AddWithValue("@StudentID", TBstudentid.Text)
                .AddWithValue("@FirstName", TBfirstname.Text)
                .AddWithValue("@Surname", TBsurname.Text)
                .AddWithValue("@Address", TBaddress.Text)
                .AddWithValue("@PostCode", TBpostcode.Text)
                .AddWithValue("@Telephone", TBtelephone.Text)
            End With

            sqlCmd.ExecuteNonQuery()
            MessageBox.Show("Record added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            sqlConn.Close()
        End Try
        updatetable()
    End Sub

    ' Update Button Event
    Private Sub btnUPDATE_Click(sender As Object, e As EventArgs) Handles btnUPDATE.Click
        Try
            sqlConn.ConnectionString = "server=" & server & ";user id=" & username & ";password=" & password & ";database=" & database
            sqlConn.Open()

            sqlQuery = "UPDATE myconnector SET FirstName=@FirstName, Surname=@Surname, Address=@Address, PostCode=@PostCode, Telephone=@Telephone WHERE StudentID=@StudentID"
            sqlCmd = New MySqlCommand(sqlQuery, sqlConn)

            With sqlCmd.Parameters
                .AddWithValue("@StudentID", TBstudentid.Text)
                .AddWithValue("@FirstName", TBfirstname.Text)
                .AddWithValue("@Surname", TBsurname.Text)
                .AddWithValue("@Address", TBaddress.Text)
                .AddWithValue("@PostCode", TBpostcode.Text)
                .AddWithValue("@Telephone", TBtelephone.Text)
            End With

            sqlCmd.ExecuteNonQuery()
            MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            sqlConn.Close()
        End Try
        updatetable()
    End Sub

    ' Delete Button Event
    Private Sub btnDELETE_Click(sender As Object, e As EventArgs) Handles btnDELETE.Click
        Try
            sqlConn.ConnectionString = "server=" & server & ";user id=" & username & ";password=" & password & ";database=" & database
            sqlConn.Open()

            sqlQuery = "DELETE FROM myconnector WHERE StudentID=@StudentID"
            sqlCmd = New MySqlCommand(sqlQuery, sqlConn)
            sqlCmd.Parameters.AddWithValue("@StudentID", TBstudentid.Text)

            sqlCmd.ExecuteNonQuery()
            MessageBox.Show("Record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            sqlConn.Close()
        End Try
        updatetable()
    End Sub

    ' Reset Button Event
    Private Sub btnRESET_Click(sender As Object, e As EventArgs) Handles btnRESET.Click
        TBstudentid.Clear()
        TBfirstname.Clear()
        TBsurname.Clear()
        TBaddress.Clear()
        TBpostcode.Clear()
        TBtelephone.Clear()
        TBsearch.Clear()
    End Sub

    ' Exit Button Event
    Private Sub btnEXIT_Click(sender As Object, e As EventArgs) Handles btnEXIT.Click
        If MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    ' Print Button Event
    Private Sub btnPRINT_Click(sender As Object, e As EventArgs) Handles btnPRINT.Click
        Try
            Dim height As Integer = DataGridView1.Height
            DataGridView1.Height = DataGridView1.RowCount * DataGridView1.RowTemplate.Height
            bitmap = New Bitmap(Me.DataGridView1.Width, Me.DataGridView1.Height)
            DataGridView1.DrawToBitmap(bitmap, New Rectangle(0, 0, Me.DataGridView1.Width, Me.DataGridView1.Height))
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
            PrintPreviewDialog1.ShowDialog()
            DataGridView1.Height = height
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Search Functionality
    Private Sub TBsearch_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TBsearch.KeyPress
        If Asc(e.KeyChar) = 13 Then
            Try
                Dim dv As New DataView(sqlDt)
                dv.RowFilter = String.Format("Firstname LIKE '%{0}%'", TBsearch.Text)
                DataGridView1.DataSource = dv
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    ' DataGridView Cell Click Event
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            TBstudentid.Text = DataGridView1.CurrentRow.Cells(0).Value.ToString()
            TBfirstname.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString()
            TBsurname.Text = DataGridView1.CurrentRow.Cells(2).Value.ToString()
            TBaddress.Text = DataGridView1.CurrentRow.Cells(3).Value.ToString()
            TBpostcode.Text = DataGridView1.CurrentRow.Cells(4).Value.ToString()
            TBtelephone.Text = DataGridView1.CurrentRow.Cells(5).Value.ToString()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(bitmap, 0, 0)
    End Sub
End Class
